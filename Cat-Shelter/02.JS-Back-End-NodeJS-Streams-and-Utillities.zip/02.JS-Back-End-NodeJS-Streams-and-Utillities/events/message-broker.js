import events from 'events'; // Core module

const eventEmmiter = new events.EventEmitter();

export default eventEmmiter;
